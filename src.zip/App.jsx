import { Routes, Route } from "react-router-dom";
import IndustryProfile from "./pages/Industry/IndustryProfile";
import PaymentPage from "./pages/Funding/PaymentPage";
import ContributePage from "./pages/Funding/ContributePage";

function App() {
  return (
    <Routes>
      <Route path="/" element={<IndustryProfile />} />
      <Route path="/payment/:id" element={<PaymentPage />} />
      <Route path="/contribute/:id" element={<ContributePage />} />
    </Routes>
  );
}

export default App;
