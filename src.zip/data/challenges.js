// Shared "source of truth" for CSR challenges.
// Later this can be swapped for an API call (services/challenges.js) —
// every page below just imports `challenges` and looks up by id, so the
// swap won't require touching IndustryProfile / PaymentPage / ContributePage.

export const solvedPrograms = [
  {
    id: "education-signature",
    year: "FY2025–26",
    category: "Education",
    title: "Education Signature Programme",
    problem:
      "Learning gaps, children out of school and unequal access to quality education.",
    contribution:
      "Programme funding + teacher/community support + learning resources.",
    amount: "₹3,00,000",
    impact: "2,961 out-of-school children brought back into the system.",
    reached: "8.19 lakh children reached",
  },
  {
    id: "lakhpati-kisan",
    year: "2015–Present",
    category: "Rural Development",
    title: "Lakhpati Kisan",
    problem:
      "Low rural income and limited livelihood opportunities among tribal households.",
    contribution:
      "Livelihood programme funding + technical support + market linkages.",
    amount: "₹3,00,000",
    impact: "45,000+ families became Lakhpati Kisans.",
    reached: "Nearly 1.1 lakh tribal households reached",
  },
  {
    id: "skill-development",
    year: "Ongoing",
    category: "Employment",
    title: "Skill Development & Livelihoods",
    problem:
      "Unemployment, limited job skills and lack of livelihood opportunities.",
    contribution:
      "Training costs + trainers + career support + programme funding.",
    amount: "₹3,00,000",
    impact: "17,098 people impacted through Model Career Centres.",
    reached: "17,098 people impacted",
  },
];

// `needs` controls which options appear in the "How would you like to
// help?" choice modal: any of "funding", "equipment", "manpower".
export const challenges = [
  {
    id: "learning-gap",
    category: "Education",
    title: "Learning gaps and unequal access to quality education",
    description:
      "Children facing learning gaps and unequal access to quality education need stronger learning support and pathways back into the education system.",
    needs: ["funding", "equipment"],
    required: 500000,
    raised: 60000,
  },
  {
    id: "job-skills",
    category: "Employment",
    title: "Limited job skills and livelihood opportunities",
    description:
      "Young people and communities facing limited job skills need vocational training, career support and sustainable livelihood opportunities.",
    needs: ["funding", "manpower"],
    required: 500000,
    raised: 320000,
  },
  {
    id: "disability-inclusion",
    category: "Disability Inclusion",
    title: "Barriers to livelihoods and employment for persons with disabilities",
    description:
      "Persons with disabilities face barriers to livelihoods, employment and inclusion and need stronger livelihood linkages and support.",
    needs: ["funding", "equipment", "manpower"],
    required: 500000,
    raised: 155000,
  },
];

export function getChallengeById(id) {
  return challenges.find((c) => c.id === id);
}
