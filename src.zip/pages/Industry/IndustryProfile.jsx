import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../../App.css";
import { solvedPrograms, challenges } from "../../data/challenges";

const needLabels = {
  funding: "Funding",
  equipment: "Equipment",
  manpower: "Manpower",
};

function IndustryProfile() {
  const navigate = useNavigate();
  const [selectedProgram, setSelectedProgram] = useState(null);
  const [choiceFor, setChoiceFor] = useState(null); // the challenge currently showing the "how to help" modal

  const openChoice = (challenge) => setChoiceFor(challenge);
  const closeChoice = () => setChoiceFor(null);

  const chooseFunding = (challenge) => {
    navigate(`/payment/${challenge.id}`);
  };

  const chooseInKind = (challenge, type) => {
    navigate(`/contribute/${challenge.id}?type=${type}`);
  };

  return (
    <div className="page">
      {/* NAVBAR */}
      <nav className="navbar">
        <div className="logo">
          <span className="logo-dot"></span>
          SETU
        </div>

        <div className="nav-right">
          <span className="company-nav">Tata Group</span>
          <button className="profile-btn">CSR Profile</button>
        </div>
      </nav>

      {/* COMPANY HERO */}
      <section className="company-hero">
        <div className="company-image">
          <img src="/tata-logo.png" alt="Tata Group" />
        </div>

        <div className="company-info">
          <div className="tag">
            <span></span>
            INDUSTRY / CSR
          </div>

          <h1>Tata Group</h1>

          <h2>
            Creating impact through
            <span> responsible action.</span>
          </h2>

          <p>
            Tata Group supports initiatives focused on education,
            livelihoods, health, inclusion and community development,
            working with communities and partner organisations to create
            meaningful social impact.
          </p>

          <div className="company-stats">
            <div>
              <strong>10</strong>
              <span>CSR Activities</span>
            </div>

            <div>
              <strong>8.19L</strong>
              <span>Children Reached</span>
            </div>

            <div>
              <strong>17,098</strong>
              <span>People Impacted</span>
            </div>
          </div>
        </div>
      </section>

      {/* SOLVED PROGRAMS */}
      <section className="section">
        <div className="section-heading">
          <div>
            <span className="small-heading">CSR IMPACT</span>
            <h2>What Tata has solved</h2>
            <p>Programs supported by Tata to address real community problems.</p>
          </div>
        </div>

        <div className="program-grid">
          {solvedPrograms.map((program) => (
            <div className="program-card" key={program.id}>
              <div className="card-top">
                <span className="category">{program.category}</span>
                <span className="year">{program.year}</span>
              </div>

              <h3>{program.title}</h3>

              <p className="card-problem">{program.problem}</p>

              <div className="impact">
                <span>IMPACT</span>
                <strong>{program.reached}</strong>
              </div>

              <button
                className="view-btn"
                onClick={() => setSelectedProgram(program)}
              >
                View impact
                <span>→</span>
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* PROBLEMS */}
      <section className="problem-section">
        <div className="section-heading">
          <div>
            <span className="small-heading">COMMUNITY NEEDS</span>
            <h2>Problems waiting for support</h2>
            <p>Choose a real community problem and contribute towards solving it.</p>
          </div>
        </div>

        <div className="problem-list">
          {challenges.map((problem, index) => (
            <div className="problem-card" key={problem.id}>
              <div className="problem-content">
                <div className="problem-number">0{index + 1}</div>

                <div>
                  <span className="problem-category">{problem.category}</span>
                  <h3>{problem.title}</h3>
                  <p>{problem.description}</p>

                  <div className="needs-chips">
                    {problem.needs.map((need) => (
                      <span className="needs-chip" key={need}>
                        {needLabels[need]}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="problem-action">
                <span className="status">PROBLEM TO SOLVE</span>

                <button className="fund-btn" onClick={() => openChoice(problem)}>
                  Fund
                  <span>→</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FOOTER */}
      <footer>
        <div className="footer-logo">
          <span className="logo-dot"></span>
          SETU
        </div>
        <p>Connecting CSR contributions with real community problems.</p>
      </footer>

      {/* SOLVED PROGRAM POPUP */}
      {selectedProgram && (
        <div className="modal-overlay" onClick={() => setSelectedProgram(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <button className="close-btn" onClick={() => setSelectedProgram(null)}>
              ×
            </button>

            <span className="modal-category">{selectedProgram.category}</span>
            <h2>{selectedProgram.title}</h2>
            <span className="modal-year">{selectedProgram.year}</span>

            <div className="modal-block">
              <label>PROBLEM</label>
              <p>{selectedProgram.problem}</p>
            </div>

            <div className="modal-block">
              <label>TATA'S CONTRIBUTION</label>
              <p>{selectedProgram.contribution}</p>
            </div>

            <div className="modal-highlight">
              <div>
                <span>FUNDED AMOUNT</span>
                <strong>{selectedProgram.amount}</strong>
              </div>
              <div>
                <span>IMPACT</span>
                <strong>{selectedProgram.impact}</strong>
              </div>
            </div>

            <button className="modal-close" onClick={() => setSelectedProgram(null)}>
              Close
            </button>
          </div>
        </div>
      )}

      {/* "HOW WOULD YOU LIKE TO HELP?" CHOICE MODAL */}
      {choiceFor && (
        <div className="modal-overlay" onClick={closeChoice}>
          <div className="modal choice-modal" onClick={(e) => e.stopPropagation()}>
            <button className="close-btn" onClick={closeChoice}>
              ×
            </button>

            <h2>How would you like to help?</h2>
            <p className="choice-subtitle">{choiceFor.title}</p>

            <div className="choice-options">
              {choiceFor.needs.includes("funding") && (
                <button className="choice-btn" onClick={() => chooseFunding(choiceFor)}>
                  Contribute funding →
                </button>
              )}
              {choiceFor.needs.includes("equipment") && (
                <button
                  className="choice-btn"
                  onClick={() => chooseInKind(choiceFor, "equipment")}
                >
                  Offer equipment →
                </button>
              )}
              {choiceFor.needs.includes("manpower") && (
                <button
                  className="choice-btn"
                  onClick={() => chooseInKind(choiceFor, "manpower")}
                >
                  Offer manpower / expertise →
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default IndustryProfile;
