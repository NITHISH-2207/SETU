import { useState } from "react";
import { useParams, useSearchParams, useNavigate, Link } from "react-router-dom";
import { getChallengeById } from "../../data/challenges";
import "./Funding.css";

const copyByType = {
  equipment: {
    label: "What equipment can you provide?",
    placeholder: "e.g. 40 water filtration units, testing kits...",
  },
  manpower: {
    label: "What manpower / expertise can you offer?",
    placeholder: "e.g. 3 engineers for 4 weeks, agricultural extension officer...",
  },
};

function ContributePage() {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const challenge = getChallengeById(id);

  const type = searchParams.get("type") === "manpower" ? "manpower" : "equipment";
  const copy = copyByType[type];

  const [email, setEmail] = useState("");
  const [details, setDetails] = useState("");

  if (!challenge) {
    return (
      <div className="funding-page">
        <div className="funding-card">
          <p>We couldn't find that challenge.</p>
          <Link className="funding-btn" to="/">
            ← Back to CSR profile
          </Link>
        </div>
      </div>
    );
  }

  const handleSubmit = () => {
    // Backend pledge-coordination integration goes here.
    alert(
      `Backend integration pending.\n\nChallenge: ${challenge.title}\nType: ${type}\nDetails: ${
        details || copy.placeholder
      }`
    );
  };

  return (
    <div className="funding-page">
      <div className="funding-card">
        <span className="funding-tag">SUPPORT PLEDGE</span>
        <h2 className="funding-title">Offer support: {challenge.title}</h2>
        <div className="funding-id">ID: {challenge.id}</div>

        <label>Organisation</label>
        <input type="text" value="Tata Group" readOnly />

        <label>Contact email</label>
        <input
          type="email"
          placeholder="csr@tata.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <label>{copy.label}</label>
        <textarea
          placeholder={copy.placeholder}
          value={details}
          onChange={(e) => setDetails(e.target.value)}
        />

        <button className="funding-btn" onClick={handleSubmit}>
          Submit pledge →
        </button>

        <div className="funding-note">
          This is a frontend placeholder — pledges are coordinated by the
          SETU team on the backend.
        </div>

        <button className="funding-back" onClick={() => navigate(-1)}>
          ← Back
        </button>
      </div>
    </div>
  );
}

export default ContributePage;
