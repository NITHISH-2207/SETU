import { useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { getChallengeById } from "../../data/challenges";
import "./Funding.css";

const paymentMethods = ["Net Banking", "PhonePe", "Razorpay"];

function PaymentPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const challenge = getChallengeById(id);

  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState(null);

  if (!challenge) {
    return (
      <div className="funding-page">
        <div className="funding-card">
          <p>We couldn't find that challenge.</p>
          <Link className="funding-btn" to="/">
            ← Back to CSR profile
          </Link>
        </div>
      </div>
    );
  }

  const remaining = Math.max(challenge.required - challenge.raised, 0);
  const percent = Math.min(
    100,
    Math.round((challenge.raised / challenge.required) * 100)
  );

  const handlePay = () => {
    const amt = amount || remaining;
    if (!method) {
      alert("Please select a payment method.");
      return;
    }
    // Backend payment gateway integration goes here (Razorpay / PhonePe / Net Banking).
    alert(
      `Backend payment integration pending.\n\nChallenge: ${challenge.title}\nAmount: ₹${amt}\nMethod: ${method}`
    );
  };

  return (
    <div className="funding-page">
      <div className="funding-card">
        <span className="funding-tag">FUNDING CHECKOUT</span>
        <h2 className="funding-title">Fund: {challenge.title}</h2>
        <div className="funding-id">ID: {challenge.id}</div>

        <div className="progress-block">
          <div className="bar">
            <div className="fill" style={{ width: `${percent}%` }} />
          </div>
          <div className="figures">
            <b>₹{challenge.raised.toLocaleString("en-IN")} raised</b>
            <span>of ₹{challenge.required.toLocaleString("en-IN")}</span>
          </div>
        </div>

        <div className="amount-row">
          <label>Amount to contribute (₹)</label>
          <input
            type="number"
            placeholder={remaining}
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />

          <label>Organisation</label>
          <input type="text" value="Tata Group" readOnly />

          <label>Payment method</label>
          <div className="pay-methods">
            {paymentMethods.map((m) => (
              <div
                key={m}
                className={`pay-method${method === m ? " selected" : ""}`}
                onClick={() => setMethod(m)}
              >
                {m}
              </div>
            ))}
          </div>

          <button className="funding-btn" onClick={handlePay}>
            Proceed to pay →
          </button>
        </div>

        <div className="funding-note">
          This is a frontend placeholder — payment gateway integration
          happens on the backend.
        </div>

        <button className="funding-back" onClick={() => navigate(-1)}>
          ← Back
        </button>
      </div>
    </div>
  );
}

export default PaymentPage;
