﻿import { useState } from "react";
import "./App.css";

const solvedPrograms = [
  {
    year: "FY2025–26",
    category: "Education",
    title: "Education Signature Programme",
    problem:
      "Learning gaps, children out of school and unequal access to quality education.",
    contribution:
      "Programme funding + teacher/community support + learning resources.",
    amount: "₹3,00,000",
    impact: "2,961 out-of-school children brought back into the system.",
    reached: "8.19 lakh children reached",
  },

  {
    year: "2015–Present",
    category: "Rural Development",
    title: "Lakhpati Kisan",
    problem:
      "Low rural income and limited livelihood opportunities among tribal households.",
    contribution:
      "Livelihood programme funding + technical support + market linkages.",
    amount: "₹3,00,000",
    impact: "45,000+ families became Lakhpati Kisans.",
    reached: "Nearly 1.1 lakh tribal households reached",
  },

  {
    year: "Ongoing",
    category: "Employment",
    title: "Skill Development & Livelihoods",
    problem:
      "Unemployment, limited job skills and lack of livelihood opportunities.",
    contribution:
      "Training costs + trainers + career support + programme funding.",
    amount: "₹3,00,000",
    impact: "17,098 people impacted through Model Career Centres.",
    reached: "17,098 people impacted",
  },
];

const problems = [
  {
    category: "Education",
    title: "Learning gaps and unequal access to quality education",
    description:
      "Children facing learning gaps and unequal access to quality education need stronger learning support and pathways back into the education system.",
  },

  {
    category: "Employment",
    title: "Limited job skills and livelihood opportunities",
    description:
      "Young people and communities facing limited job skills need vocational training, career support and sustainable livelihood opportunities.",
  },

  {
    category: "Disability Inclusion",
    title: "Barriers to livelihoods and employment for persons with disabilities",
    description:
      "Persons with disabilities face barriers to livelihoods, employment and inclusion and need stronger livelihood linkages and support.",
  },
];

function App() {
  const [selectedProgram, setSelectedProgram] = useState(null);

  const handleFund = (problem) => {
    // Later we will connect this to your payment page.
    window.location.href = `/payment?problem=${encodeURIComponent(
      problem.title
    )}`;
  };

  return (
    <div className="page">

      {/* NAVBAR */}
      <nav className="navbar">
        <div className="logo">
          <span className="logo-dot"></span>
          SETU
        </div>

        <div className="nav-right">
          <span className="company-nav">Tata Group</span>
          <button className="profile-btn">CSR Profile</button>
        </div>
      </nav>

      {/* COMPANY HERO */}
      <section className="company-hero">

        <div className="company-image">
          {/* Replace tata-logo.png with your uploaded Tata image */}
          <img
            src="/tata-logo.png"
            alt="Tata Group"
          />
        </div>

        <div className="company-info">

          <div className="tag">
            <span></span>
            INDUSTRY / CSR
          </div>

          <h1>
            Tata Group
          </h1>

          <h2>
            Creating impact through
            <span> responsible action.</span>
          </h2>

          <p>
            Tata Group supports initiatives focused on education,
            livelihoods, health, inclusion and community development,
            working with communities and partner organisations to
            create meaningful social impact.
          </p>

          <div className="company-stats">
            <div>
              <strong>10</strong>
              <span>CSR Activities</span>
            </div>

            <div>
              <strong>8.19L</strong>
              <span>Children Reached</span>
            </div>

            <div>
              <strong>17,098</strong>
              <span>People Impacted</span>
            </div>
          </div>

        </div>
      </section>


      {/* SOLVED PROGRAMS */}
      <section className="section">

        <div className="section-heading">
          <div>
            <span className="small-heading">
              CSR IMPACT
            </span>

            <h2>
              What Tata has solved
            </h2>

            <p>
              Programs supported by Tata to address real community problems.
            </p>
          </div>
        </div>


        <div className="program-grid">

          {solvedPrograms.map((program, index) => (
            <div className="program-card" key={index}>

              <div className="card-top">
                <span className="category">
                  {program.category}
                </span>

                <span className="year">
                  {program.year}
                </span>
              </div>

              <h3>
                {program.title}
              </h3>

              <p className="card-problem">
                {program.problem}
              </p>

              <div className="impact">
                <span>IMPACT</span>
                <strong>{program.reached}</strong>
              </div>

              <button
                className="view-btn"
                onClick={() => setSelectedProgram(program)}
              >
                View impact
                <span>→</span>
              </button>

            </div>
          ))}

        </div>
      </section>


      {/* PROBLEMS */}
      <section className="problem-section">

        <div className="section-heading">

          <div>
            <span className="small-heading">
              COMMUNITY NEEDS
            </span>

            <h2>
              Problems waiting for support
            </h2>

            <p>
              Choose a real community problem and contribute towards solving it.
            </p>
          </div>

        </div>


        <div className="problem-list">

          {problems.map((problem, index) => (

            <div className="problem-card" key={index}>

              <div className="problem-content">

                <div className="problem-number">
                  0{index + 1}
                </div>

                <div>

                  <span className="problem-category">
                    {problem.category}
                  </span>

                  <h3>
                    {problem.title}
                  </h3>

                  <p>
                    {problem.description}
                  </p>

                </div>

              </div>


              <div className="problem-action">

                <span className="status">
                  PROBLEM TO SOLVE
                </span>

                <button
                  className="fund-btn"
                  onClick={() => handleFund(problem)}
                >
                  Fund
                  <span>→</span>
                </button>

              </div>

            </div>

          ))}

        </div>

      </section>


      {/* FOOTER */}
      <footer>
        <div className="footer-logo">
          <span className="logo-dot"></span>
          SETU
        </div>

        <p>
          Connecting CSR contributions with real community problems.
        </p>
      </footer>


      {/* POPUP */}
      {selectedProgram && (

        <div
          className="modal-overlay"
          onClick={() => setSelectedProgram(null)}
        >

          <div
            className="modal"
            onClick={(e) => e.stopPropagation()}
          >

            <button
              className="close-btn"
              onClick={() => setSelectedProgram(null)}
            >
              ×
            </button>

            <span className="modal-category">
              {selectedProgram.category}
            </span>

            <h2>
              {selectedProgram.title}
            </h2>

            <span className="modal-year">
              {selectedProgram.year}
            </span>


            <div className="modal-block">

              <label>
                PROBLEM
              </label>

              <p>
                {selectedProgram.problem}
              </p>

            </div>


            <div className="modal-block">

              <label>
                TATA'S CONTRIBUTION
              </label>

              <p>
                {selectedProgram.contribution}
              </p>

            </div>


            <div className="modal-highlight">

              <div>
                <span>
                  FUNDED AMOUNT
                </span>

                <strong>
                  {selectedProgram.amount}
                </strong>
              </div>

              <div>
                <span>
                  IMPACT
                </span>

                <strong>
                  {selectedProgram.impact}
                </strong>
              </div>

            </div>


            <button
              className="modal-close"
              onClick={() => setSelectedProgram(null)}
            >
              Close
            </button>

          </div>

        </div>

      )}

    </div>
  );
}

export default App;